use apuestas;

#Inserts de los administradores
insert into cuenta (cod_cuenta, nombre_cuenta, email, contraseña) values (001, "Adrian", "adrianmosan@gmail.com", "abcd*1234");
insert into cuenta (cod_cuenta, nombre_cuenta, email, contraseña) values (002, "Gaizka", "gaizkagorrotxategi87@gmail.com", "abcd*1234");
insert into cuenta (cod_cuenta, nombre_cuenta, email, contraseña) values (003, "Paula", "paulajimenezbenito@gmail.com", "abcd*1234");

insert into administrador (cod_cuenta) values (001);
insert into administrador (cod_cuenta) values (002);
insert into administrador (cod_cuenta) values (003);




#Inserts de deportes
insert into deporte (cod_dep, nombre) values (001, "Futbol");
insert into deporte (cod_dep, nombre) values (002, "Futbol Sala");
insert into deporte (cod_dep, nombre) values (003, "Balonmano");




#Inserts de competicion
insert into competicion (cod_comp, nombre, deporte) values (001, "Amistoso", "Futbol");
insert into competicion (cod_comp, nombre, deporte) values (002, "Liga Santander (España)", "Futbol");
insert into competicion (cod_comp, nombre, deporte) values (003, "Serie A (Italia)", "Futbol");
insert into competicion (cod_comp, nombre, deporte) values (004, "LNFS Primera Division (España)", "Futbol Sala ");
insert into competicion (cod_comp, nombre, deporte) values (005, "Liga Asobal (España)", "Balonmano");




#Inserts de Equipos
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (001, 'Athletic Club', 1898, 'Bilbao', 'España', 'San Mamés');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (002, 'Atlético de Madrid', 1903,	'Madrid', 'España', 'Civitas Metropolitano');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (003, 'UD Almeria', 1989, 'Almeria', 'España', 'Power Horse Stadium');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (004, 'FC Barcelona', 1899, 'Barcelona', 'España', 'Spotify Camp Nou');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (005, 'Cádiz CF', 1910, 'Cádiz', 'España', 'Estadio Nuevo Mirandilla');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (006, 'RC Celta de Vigo', 1923, 'Vigo', 'España', 'Abanca-Balaídos');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (007, 'Elche CF', 1922, 'Elche', 'España', 'Martinez Valero');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (008, 'RCD Espanyol', 1900, 'Barcelona', 'España', 'RCDE Stadium');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (009, 'Getafe CF', 1983, 'Getafe', 'España', 'Coliseum Alfonso Pérez');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (010, 'Girona FC', 1930, 'Girona', 'España', 'Montilivi');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (011, 'RCD Mallorca', 1916, 'Mallorca', 'España', 'Son Moix');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (012, 'CA Osasuna', 1919, 'Pamplona', 'España', 'El Sadar');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (013, 'Rayo Vallecano', 1924, 'Vallecas', 'España', 'Estadio de Vallecas');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (014, 'Real Betis Balonpié', 1907, 'Sevilla', 'España', 'Benito Villamarín');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (015, 'Real Madrid CF', 1902, 'Madrid', 'España', 'Santiago Bernabéu');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (016, 'Real Sociedad', 1909, 'San Sebastián', 'España', 'Reale Arena');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (017, 'Real Valladolid CF', 1928, 'Valladolid', 'España', 'José Zorrilla');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (018, 'Sevilla FC', 1890, 'Sevilla', 'España', 'Ramón Sánchez-Pizjuán');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (019, 'Valencia CF', 1919, 'Valencia', 'España', 'Mestalla');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (020, 'Villarreal CF', 1942, 'Villarreal', 'España', 'Estadio de la Cerámica');

insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (021, 'Atalanta', 1907,	'Bergamo', 'Italia', 'Gewiss Stadium');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (022, 'Bologna', 1909,	'Bolonia', 'Italia', 'Renato Dall´Ara');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (023, 'U.S. Cremonese', 1903, 'Cremona', 'Italia', 'Stadio Giovanni Zini');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (024, 'Empoli F.C.', 1920,	'Empoli', 'Italia', 'Estadio Carlo Castellani');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (025, 'Fiorentina', 1926,	'Florencia', 'Italia', 'Artemio Franchi');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (026, 'Hellas Verona F.C.', 1903,	'Verona', 'Italia', 'Marcantonio Bentegodi');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (027, 'Internazionale', 1908,	'Milan', 'Italia', 'Giuseppe Meazza');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (028, 'Juventus', 1897,	'Turin', 'Italia', 'Allianz Stadium');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (029, 'Lazio', 1900, 'Roma', 'Italia', 'Olímpico de Roma');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (030, 'U.S. Lecce', 1908, 'Lecce', 'Italia', 'Stadio Via del Mare');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (031, 'A.C. Milan', 1899, 'Milan', 'Italia', 'Calcistico San Siro');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (032, 'A.C. Monza', 1912, 'Monza', 'Italia', 'Estadio Brianteo');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (033, 'S.S.C Napoli', 1926, 'Napoles', 'Italia', 'Diego Armando Maradona');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (034, 'A.S. Roma', 1927, 'Roma', 'Italia', 'Olimpico de Roma');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (035, 'U.S. Salernitana', 1919, 'Salermo', 'Italia', 'Arechi');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (036, 'U.C. Sampdoria', 1946, 'Genova', 'Italia', 'Stadio Luigi Ferraris');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (037, 'Sassuolo Calcio', 1920, 'Reggio Emilia', 'Italia', 'MAPEI Stadium - Citta del Tricolore');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (038, 'Spezia Calcio', 1906, 'Via Nicolo Fieschi', 'Italia', 'Estadio Alberto Picco');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (039, 'Torino F.C.', 1906, 'Turin', 'Italia', 'Olimpico de Turin');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (040, 'Udinese', 1896, 'Udine', 'Italia', 'Stadio Friuli');

insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (041, 'Barça', 1978, 'Barcelona', 'España', 'Palau Blaugrana');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (042, 'Cordoba Patrimonio de la Humanidad', 2013, 'Cordoba', 'España', 'Palacio Municipal de Deportes Vista Alegre');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (043, 'ElPozo Murcia Costa Calida', 1989, 'Murcia', 'España', 'Palacio de Deportes de Murcia');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (044, 'Industrias Santa Coloma', 1975, 'Santa Coloma de Gramenet', 'España', 'Pabellon Nuevo');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (045, 'Inter FS', 1977, 'Torrejon de Ardoz', 'España', 'Jorge Garbajosa');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (046, 'Jaen FS', 1980, 'Jaen', 'España', 'Olivo Arena');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (047, 'Jimbee Cartagena', 2013, 'Cartagena', 'España', 'Palacio de los Deportes de Cartagena');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (048, 'Levante UD FS', 2005, 'Valencia', 'España', 'Pabellon Municipal de Paterna');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (049, 'Quesos Hidalgo Manzanares FS', 2001, 'Manzanares', 'España', 'Pabellon Municipal Antonio Caba');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (050, 'Xota FS', 1978, 'Pamplona', 'España', 'Anaitasuna');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (051, 'Mallorca Palma Futsal', 1998, 'Palma(Baleares)', 'España', 'Palau Municipal d´Esports de Son Moix');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (052, 'Viña Albali Valdepeñas', 2002, 'Valdepeñas', 'España', 'Virgen de la Cabeza');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (053, 'Ribera Navarra FS', 2001, 'Tudela', 'España', 'Ciudad de Tudela');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (054, 'Real Betis Futsal', 1987, 'Sevilla', 'España', 'Pabellon de San Pablo');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (055, 'BeSoccer CD UMA Antequera', 1985, 'Antequera', 'España', 'Fernando Argüelles');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (056, 'Noia Portus Apostoli', 2008, 'Noia(A Coruña)', 'España', 'Pabellon Municipal Agustin Mouris');

insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (057, 'Barca', 1943, 'Barcelona', 'España', 'Palau Blaugrana');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (058, 'Rebi Balonmano Cuenca', 1989, 'Cuenca', 'España', 'Pabellón Municipal El Sargal');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (059, 'BM Granollers', 1944, 'Granollers', 'España', 'Palacio de Deportes de Granollers');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (060, 'Bidasoa Irun', 1962, 'Irún', 'Epaña', 'Polideportivo Artaleku');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (061, 'BM Logroño La Rioja', 2003, 'Logroño', 'España', 'Palacio de los Deportes');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (062, 'Abanca Ademar León', 1956, 'Léon', 'España', 'Palacio Municipal de los Deportes');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (063, 'Angel Ximénez-Avia Puente Genil', 1984, 'Puente Genil', 'Córdoba', 'Polideportivo Municipal Alcalde Miguel Salas');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (064, 'Bathco BM Torrelavega', 2002, 'Torrelavega', 'España', 'Pabellón Vicente Trueba');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (065, 'Bada Huesca', 1995, 'Huesca', 'España', 'Palacio Municipal de Deportes');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (066, 'TM Benidorm', 1994, 'Benidorm', 'España', 'Pabellón Liliana Fernández');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (067, 'Helvetia Anaitasuna', 1956, 'Pamplona', 'España', 'Pabellón Anaitasuna');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (068, 'Balonmano Sinfín', 2004, 'Santander', 'España', 'Pabellón de La Albericia');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (069, 'Frigoríficos del Morrazo', 1961, 'Cangas de Morrazo', 'España', 'Municipal O Gatañal');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (070, 'Recoletas Atlético Valladolid', 2014, 'Valladolid', 'España', 'Polideportivo Huerta del Rey');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (071, 'Balonmano Guadalajara', 2007, 'Guadalajara', 'España', 'Polideportivo Municipal David Santamaría');
insert into equipo (cod_equipo, nombre, fecha_fun, localidad, pais, estadio) values (072, 'Club Cisne BM', 1964, 'Pontevedra', 'España', 'Estadio da Xuventude');



#Inserts de Equipos que pertenecen a una competicion de un deporte
insert into participar (cod_equipo, cod_comp, cod_dep) values (001, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (002, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (003, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (004, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (005, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (006, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (007, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (008, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (009, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (010, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (011, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (012, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (013, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (014, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (015, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (016, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (017, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (018, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (019, 002, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (020, 002, 001);

insert into participar (cod_equipo, cod_comp, cod_dep) values (021, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (022, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (023, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (024, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (025, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (026, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (027, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (028, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (029, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (030, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (031, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (032, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (033, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (034, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (035, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (036, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (037, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (038, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (039, 003, 001);
insert into participar (cod_equipo, cod_comp, cod_dep) values (040, 003, 001);


insert into participar (cod_equipo, cod_comp, cod_dep) values (041, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (042, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (043, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (044, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (045, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (046, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (047, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (048, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (049, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (050, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (051, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (052, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (053, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (054, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (055, 004, 002);
insert into participar (cod_equipo, cod_comp, cod_dep) values (056, 004, 002);

insert into participar (cod_equipo, cod_comp, cod_dep) values (057, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (058, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (059, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (060, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (061, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (062, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (063, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (064, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (065, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (066, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (067, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (068, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (069, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (070, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (071, 005, 003);
insert into participar (cod_equipo, cod_comp, cod_dep) values (072, 005, 003);













#Inserts de Jugadores
#insert into jugador (id_jugador, nombre, apellido1, apellido2, fecha_nac, dorsal, cod_equipo) values ();
